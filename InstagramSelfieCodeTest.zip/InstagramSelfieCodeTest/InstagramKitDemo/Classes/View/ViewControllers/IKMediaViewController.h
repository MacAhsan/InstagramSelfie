//  Created by Muhammad Ahsan on 01/20/15.
// Code Test
//

#import <UIKit/UIKit.h>
@class InstagramMedia;
@interface IKMediaViewController : UITableViewController

@property (nonatomic, strong) InstagramMedia *media;
@end
