//  Created by Muhammad Ahsan on 01/20/15.
// Code Test
//

#import <UIKit/UIKit.h>

@interface IKCollectionViewController : UICollectionViewController
- (IBAction)reloadMedia;
@end
