//  Created by Muhammad Ahsan on 01/20/15.
// Code Test
//

#import <UIKit/UIKit.h>

@interface IKCell : UICollectionViewCell

@property (strong, nonatomic) IBOutlet UIImageView *imageView;

@end
