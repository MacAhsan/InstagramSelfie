//  Created by Muhammad Ahsan on 01/20/15.
// Code Test
//

#import "IKMediaCell.h"

@implementation IKMediaCell

@end
