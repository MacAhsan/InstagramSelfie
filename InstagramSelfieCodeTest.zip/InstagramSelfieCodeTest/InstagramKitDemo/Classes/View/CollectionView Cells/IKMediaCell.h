//  Created by Muhammad Ahsan on 01/20/15.
// Code Test
//

#import <UIKit/UIKit.h>

@interface IKMediaCell : UITableViewCell
@property (nonatomic, strong) IBOutlet UIImageView *mediaImageView;
@end
