//  Created by Muhammad Ahsan on 01/20/15.
// Code Test
//


#import <Foundation/Foundation.h>

@interface InstagramTag : NSObject

@property (readonly) NSString* name;
@property (readonly) NSInteger mediaCount;

@end
